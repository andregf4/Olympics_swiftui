//
//  ChartsArtsApp.swift
//  ChartsArts
//
//  Created by Andre Gerez Foratto on 13/05/24.
//

import SwiftUI

@main
struct ChartsArtsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
